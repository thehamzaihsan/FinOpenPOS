import { NextResponse } from "next/server";
import pb from "@/lib/pb";
import { ensureCollections } from "@/lib/ensure-collections";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    await ensureCollections();
    const products = await pb.collection("products").getFullList({
      filter: "is_active = true",
      sort: "-created",
    });
    return NextResponse.json({ success: true, data: products });
  } catch (error: any) {
    console.error("Products GET error:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    await ensureCollections();
    
    const body = await request.json();
    
    if (!body.name) {
      return NextResponse.json({ success: false, error: "Product name is required" }, { status: 400 });
    }
    
    const product = await pb.collection("products").create({
      name: body.name,
      sku: body.sku || "",
      price: body.price || 0,
      stock: body.stock || 0,
      category: body.category || "",
      is_active: true,
    });
    
    return NextResponse.json({ success: true, data: product });
  } catch (error: any) {
    console.error("Products POST error:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}