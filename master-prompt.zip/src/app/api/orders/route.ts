import { NextResponse, NextRequest } from "next/server";
import { randomUUID } from "node:crypto";
import { getDb } from "@/lib/sqlite";

export async function GET(request: NextRequest) {
  try {
    const db = getDb();
    const orders = db.prepare("SELECT * FROM orders ORDER BY created_at DESC").all();
    return NextResponse.json({ success: true, data: orders });
  } catch (error) {
    return NextResponse.json({ success: false, error: "Failed to fetch orders" }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const db = getDb();
    const body = await request.json();
    const { items, customer, is_khata, payment_method, total_amount } = body;

    if (!items || items.length === 0) {
      return NextResponse.json({ success: false, error: "Order items required" }, { status: 400 });
    }

    const orderItems: any[] = [];
    for (const item of items) {
      const product = db.prepare("SELECT * FROM products WHERE id = ?").get(item.product) as any;
      if (!product) {
        return NextResponse.json({ success: false, error: `Product not found: ${item.product}` }, { status: 404 });
      }

      if (product.stock < item.quantity) {
        return NextResponse.json({
          success: false,
          error: `Insufficient stock for ${product.name}. Available: ${product.stock}`
        }, { status: 400 });
      }

      db.prepare("UPDATE products SET stock = ? WHERE id = ?").run((product.stock || 0) - item.quantity, item.product);

      orderItems.push({
        order: "",
        product: item.product,
        quantity: item.quantity,
        unit_price: item.unit_price,
        total_price: item.total_price,
      });
    }

    const orderId = randomUUID();
    db.prepare(
      "INSERT INTO orders (id, customer, total_amount, payment_method, status, is_khata, is_active, created_at) VALUES (?, ?, ?, ?, 'paid', ?, 1, ?)"
    ).run(
      orderId,
      customer || null,
      Number(total_amount || 0),
      payment_method || "cash",
      is_khata ? 1 : 0,
      new Date().toISOString()
    );

    for (const item of orderItems) {
      db.prepare(
        "INSERT INTO order_items (id, order_id, product, quantity, unit_price, total_price) VALUES (?, ?, ?, ?, ?, ?)"
      ).run(randomUUID(), orderId, item.product, Number(item.quantity || 0), Number(item.unit_price || 0), Number(item.total_price || 0));
    }

    const order = db.prepare("SELECT * FROM orders WHERE id = ?").get(orderId);
    return NextResponse.json({ success: true, data: order });
  } catch (error: any) {
    console.error("Order creation error:", error);
    return NextResponse.json({ success: false, error: error.message || "Failed to create order" }, { status: 500 });
  }
}