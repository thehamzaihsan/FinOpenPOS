import { NextResponse, NextRequest } from "next/server";
import { randomUUID } from "node:crypto";
import { getDb } from "@/lib/sqlite";

export async function GET(request: NextRequest) {
  try {
    const db = getDb();
    const customers = db.prepare("SELECT * FROM customers WHERE is_active = 1 ORDER BY created_at DESC").all();
    return NextResponse.json({ success: true, data: customers });
  } catch (error) {
    return NextResponse.json({ success: false, error: "Failed to fetch customers" }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const db = getDb();
    const body = await request.json();
    const id = randomUUID();
    db.prepare(
      "INSERT INTO customers (id, name, phone, address, is_active, created_at) VALUES (?, ?, ?, ?, 1, ?)"
    ).run(id, body.name || "Customer", body.phone || "", body.address || "", new Date().toISOString());
    const customer = db.prepare("SELECT * FROM customers WHERE id = ?").get(id);
    return NextResponse.json({ success: true, data: customer });
  } catch (error) {
    return NextResponse.json({ success: false, error: "Failed to create customer" }, { status: 500 });
  }
}